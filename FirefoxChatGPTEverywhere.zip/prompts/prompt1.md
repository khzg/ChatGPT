Use this link [![(New issue)]()](https://github.com/khzg/ChatGPT/issues) to publish your prompt.
___
khashayar: you can give the picture with the following text to Google Gemini to write a prompt for creating a picture. If the prompt is long, tell him to shorten it:

What prompt should I use to make a picture exactly like this? Tell me precisely and professionally.
___
khashayar: Propose a novel concept for a futuristic city that maximizes sustainability, promotes social inclusivity, and enhances the overall quality of life for its residents.
___

