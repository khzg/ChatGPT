Use this link [![(New issue)]()](https://github.com/khzg/ChatGPT/issues) to publish your prompt.
___
khashayar: you can give the picture with the following text to Google Gemini to write a prompt for creating a picture. If it doesn't recognize the character in the picture, ask AI first who is the character in the picture and then tell AI in the prompt. It doesn't work on people's pictures because of privacy. If the prompt is long, tell him to shorten it or add more details and edit it by chatting :

prompt: What prompt should I use to make a picture exactly like this?
with a detailed description of the style, quality of the image I gave you.
___
khashayar: Propose a novel concept for a futuristic city that maximizes sustainability, promotes social inclusivity, and enhances the overall quality of life for its residents.
___

